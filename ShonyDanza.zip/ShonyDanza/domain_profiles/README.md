This is an empty directory where domain profile results will be saved for the user. 
