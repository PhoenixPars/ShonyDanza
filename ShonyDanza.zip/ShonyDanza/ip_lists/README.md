This is an empty directory where IP results will be saved for the user. 
