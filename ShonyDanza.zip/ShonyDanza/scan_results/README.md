This is an empty directory where on-demand scan results will be saved for the user. 
