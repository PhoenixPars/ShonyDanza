This is an empty directory where host profile results will be saved for the user. 
